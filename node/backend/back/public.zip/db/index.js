let mysql = require('mysql')
let pool = mysql.createPool({
  host: 'gz-cynosdbmysql-grp-pd4ndjr1.sql.tencentcdb.com',
  user: 'root',
  password: '19980508cX',
  port: '27251',
  database: 'test',
  multipleStatements: true,
  connectionLimit:50,
});
let query = function (sql, data, callback) {
  // console.log('data',data)
  pool.getConnection(function (err, conn) {
    if (err) {
      console.log('sql connect err',err)
      callback(err, null, null);
    } else {
      conn.query(sql, data, function (qerr, vals, fields) {
        //释放连接
        console.log('释放连接',data)
        conn.release();
        //事件驱动回调
        callback(qerr, vals, fields);
        // console.log('回调',data)
      });
    }
  });
}
let transction = function (sqls, params) {
  return new Promise((resolve, reject) => {
    pool.getConnection(function (err, connection) {
      // 连接失败 promise直接返回失败
      if (err) {
        console.log('链接失败')
        return reject(err);
      }
      // 如果 语句和参数数量不匹配 promise直接返回失败
      if (sqls.length !== params.length) {
        connection.release(); // 释放掉
        return reject(new Error("语句与传值不匹配"));
      }
      // 开始执行事务
      connection.beginTransaction((beginErr) => {
        // 创建事务失败
        if (beginErr) {
          connection.release();
          return reject(beginErr);
        }
        // console.log("开始执行事务，共执行" + sqls.length + "条语句");
        // 返回一个promise 数组
        let funcAry = sqls.map((sql, index) => {
          return new Promise((sqlResolve, sqlReject) => {
            const data = params[index];
            connection.query(sql, data, (sqlErr, result) => {
              // console.log(sqlErr,result)
              if (sqlErr) {
                return sqlReject(sqlErr);
              }
              sqlResolve(result);
            });
          });
        });
        // 使用all 方法 对里面的每个promise执行的状态 检查
        Promise.all(funcAry)
          .then((arrResult) => {
            // 若每个sql语句都执行成功了 才会走到这里 在这里需要提交事务，前面的sql执行才会生效
            // 提交事务
            connection.commit(function (commitErr, info) {
              if (commitErr) {
                // 提交事务失败了
                console.log("提交事务失败:" + commitErr);
                // 事务回滚，之前运行的sql语句不生效
                connection.rollback(function (err) {
                  if (err) console.log("回滚失败：" + err);
                  connection.release();
                });
                // 返回promise失败状态
                return reject(commitErr);
              }

              connection.release();
              // 事务成功 返回 每个sql运行的结果 是个数组结构
              resolve(arrResult);
            });
          })
          .catch((error) => {
            // 多条sql语句执行中 其中有一条报错 直接回滚
            connection.rollback(function () {
              console.log("sql运行失败： " + error);
              connection.release();
              reject(error);
            });
          });
      });
    });
  });
}
module.exports = {
  query,
  transction
};