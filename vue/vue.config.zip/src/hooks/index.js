import {get,post} from '@/api/http'

export function useGet(){
    return get
}
export function usePost(){
    return post
}