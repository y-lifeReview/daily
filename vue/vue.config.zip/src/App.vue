<template>
  <router-view />
</template>
<script>


import { Snow } from "snowjs";

export default {
  data() {
    return {};
  },
  methods: {},
  mounted() {
    // new wow({
    //   offset: 50,
    // }).init();
    // console.log("mounted");
    window.scrollTo(0, 0);

    let snow = new Snow("snowcavas",null,null,150,1,5,.5,1,true);
    snow.start();
  },
};
</script>
<style></style>
