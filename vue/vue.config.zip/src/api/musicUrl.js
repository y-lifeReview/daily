
export const urlForGetMusicList = '/music/getMusicList';
export const urlForGetMusicUrls = '/music/getMusicUrls';