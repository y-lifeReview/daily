
import router from "../router";


router.beforeEach(async () => {
    // to and from are both route objects. must call `next`.
    // console.log('beforeEach', to)
    

})
router.afterEach(() => {
    
});